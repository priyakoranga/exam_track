from datetime import date, datetime
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from app import db
from app.models import Reminder
from app.services import refresh_all_reminders

_scheduler = None

def _daily_job(app):
    with app.app_context():
        refresh_all_reminders()
        today = date.today()
        due = Reminder.query.filter_by(status="Scheduled").filter(Reminder.due_date <= today).all()
        for reminder in due:
            # Initial delivery is in-app. Email/push can be added as separate adapters later.
            reminder.status = "Sent"
            reminder.sent_at = datetime.utcnow()
        db.session.commit()

def start_scheduler(app):
    global _scheduler
    if _scheduler and _scheduler.running:
        return
    _scheduler = BackgroundScheduler(timezone=app.config.get("TIMEZONE", "Asia/Kolkata"))
    _scheduler.add_job(
        _daily_job, CronTrigger(hour=8, minute=0, timezone=app.config.get("TIMEZONE", "Asia/Kolkata")),
        args=[app], id="daily_exam_reminders", replace_existing=True, coalesce=True,
        max_instances=1
    )
    _scheduler.start()
