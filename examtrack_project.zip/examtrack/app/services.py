from datetime import date, timedelta
from sqlalchemy.exc import IntegrityError
from app import db
from app.models import Exam, Stage, Reminder

STAGE_ORDER = {"Prelims": 1, "Mains": 2, "Interview": 3, "Final Result": 4}

def reconcile_reminders(exam: Exam):
    """Create missing reminders and cancel obsolete ones. Unique keys prevent duplicates."""
    today = date.today()
    desired = {}
    if not exam.archived and exam.interest_status == "Interested" and exam.registration_status not in ("Registered", "Not Interested", "Missed") and exam.registration_end:
        for days in (7, 3, 1, 0):
            due = exam.registration_end - timedelta(days=days)
            if due >= today:
                label = "today" if days == 0 else f"in {days} day(s)"
                desired[f"registration:{exam.id}:{days}:{exam.registration_end.isoformat()}"] = (
                    None, "Registration", due,
                    f"{exam.name}: registration closes {label} ({exam.registration_end.isoformat()})."
                )
    for stage in exam.stages:
        if not stage.enabled or not stage.exam_date:
            continue
        # Conditional later-stage reminders only activate after the previous stage is qualified.
        stage_order = STAGE_ORDER.get(stage.name, 0)
        if stage_order >= 2:
            prior_name = "Prelims" if stage.name == "Mains" else "Mains" if stage.name == "Interview" else "Interview"
            prior = next((s for s in exam.stages if s.name == prior_name and s.enabled), None)
            if prior and prior.qualification_status != "Qualified":
                continue
        for days in (7, 3, 1):
            due = stage.exam_date - timedelta(days=days)
            if due >= today:
                desired[f"stage:{exam.id}:{stage.id}:{days}:{stage.exam_date.isoformat()}"] = (
                    stage.id, stage.name, due,
                    f"{exam.name}: {stage.name} exam is in {days} day(s), on {stage.exam_date.isoformat()}."
                )
    existing = {r.unique_key: r for r in exam.reminders}
    for key, (stage_id, kind, due, message) in desired.items():
        if key not in existing:
            db.session.add(Reminder(
                exam_id=exam.id, stage_id=stage_id, kind=kind, due_date=due,
                message=message, unique_key=key, status="Scheduled"
            ))
        elif existing[key].status == "Cancelled":
            existing[key].status = "Scheduled"
            existing[key].due_date = due
            existing[key].message = message
    for key, reminder in existing.items():
        if key not in desired and reminder.status == "Scheduled":
            reminder.status = "Cancelled"
    try:
        db.session.flush()
    except IntegrityError:
        db.session.rollback()

def refresh_all_reminders():
    for exam in Exam.query.all():
        reconcile_reminders(exam)
    db.session.commit()
