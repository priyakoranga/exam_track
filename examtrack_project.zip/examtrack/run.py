from app import create_app

app = create_app()

if __name__ == "__main__":
    # use_reloader=False avoids starting the scheduler twice in development.
    app.run(debug=True, use_reloader=False)
