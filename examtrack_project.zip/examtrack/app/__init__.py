import os
from pathlib import Path
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    app.config.from_mapping(
        SECRET_KEY=os.environ.get("EXAMTRACK_SECRET_KEY", "change-this-local-dev-secret"),
        SQLALCHEMY_DATABASE_URI=os.environ.get(
            "DATABASE_URL", "sqlite:///" + str(Path(app.instance_path) / "examtrack.db")
        ),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        MAX_CONTENT_LENGTH=10 * 1024 * 1024,
        UPLOAD_FOLDER=str(Path(app.instance_path) / "uploads"),
        TIMEZONE="Asia/Kolkata",
    )
    if test_config:
        app.config.update(test_config)

    Path(app.config["UPLOAD_FOLDER"]).mkdir(parents=True, exist_ok=True)
    db.init_app(app)

    from app.models import Exam, Stage, SubjectMark, HistoricalStat, Reminder, Document
    from app.routes import bp
    from app.reminders import start_scheduler

    app.register_blueprint(bp)

    with app.app_context():
        db.create_all()

    # Start scheduler only for the normal app, not test clients.
    if not app.config.get("TESTING"):
        start_scheduler(app)

    return app
