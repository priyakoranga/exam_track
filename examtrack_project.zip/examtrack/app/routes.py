import json
import os
import uuid
from datetime import date, datetime
from pathlib import Path
from flask import Blueprint, abort, current_app, flash, jsonify, redirect, render_template, request, send_from_directory, url_for
from werkzeug.utils import secure_filename
from app import db
from app.models import Exam, Stage, SubjectMark, HistoricalStat, Reminder, Document
from app.services import reconcile_reminders

bp = Blueprint("main", __name__)
ALLOWED_EXTENSIONS = {"pdf", "png", "jpg", "jpeg", "doc", "docx"}

def parse_date(value):
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None

def parse_float(value):
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (ValueError, TypeError):
        return None

@bp.app_template_filter("datefmt")
def datefmt(value):
    return value.strftime("%d %b %Y") if value else "Not set"

@bp.route("/")
def dashboard():
    today = date.today()
    exams = Exam.query.filter_by(archived=False).order_by(Exam.registration_end.asc()).all()
    upcoming = []
    for exam in exams:
        if exam.registration_end and exam.registration_end >= today and exam.registration_status != "Registered":
            upcoming.append((exam, "Registration closes", exam.registration_end))
        for stage in exam.stages:
            if stage.enabled and stage.exam_date and stage.exam_date >= today:
                upcoming.append((exam, stage.name, stage.exam_date))
    upcoming.sort(key=lambda x: x[2])
    reminders = Reminder.query.filter(Reminder.status.in_(["Scheduled", "Sent"])).order_by(Reminder.due_date.asc()).limit(30).all()
    return render_template("dashboard.html", exams=exams, upcoming=upcoming[:12], reminders=reminders, today=today)

@bp.route("/exams")
def exams_list():
    status = request.args.get("status", "")
    q = Exam.query
    if request.args.get("archived") != "1":
        q = q.filter_by(archived=False)
    else:
        q = q.filter_by(archived=True)
    if status:
        q = q.filter_by(registration_status=status)
    search = request.args.get("q", "").strip()
    if search:
        q = q.filter(Exam.name.ilike(f"%{search}%"))
    return render_template("exams.html", exams=q.order_by(Exam.name.asc()).all(), status=status, search=search)

@bp.route("/exams/new", methods=["GET", "POST"])
def exam_new():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("Exam name is required.", "error")
            return render_template("exam_form.html", exam=None)
        exam = Exam(
            name=name, organization=request.form.get("organization", "").strip(),
            category=request.form.get("category", "").strip(), post_name=request.form.get("post_name", "").strip(),
            recruitment_year=request.form.get("recruitment_year", "").strip(),
            notification_url=request.form.get("notification_url", "").strip(),
            application_url=request.form.get("application_url", "").strip(),
            interest_status=request.form.get("interest_status", "Interested"),
            registration_start=parse_date(request.form.get("registration_start")),
            registration_end=parse_date(request.form.get("registration_end")),
            registration_status=request.form.get("registration_status", "Not Started"),
            application_date=parse_date(request.form.get("application_date")),
            application_number=request.form.get("application_number", "").strip(),
            fee_amount=parse_float(request.form.get("fee_amount")),
            payment_status=request.form.get("payment_status", "Unknown"),
            notes=request.form.get("notes", "").strip(),
        )
        db.session.add(exam)
        db.session.flush()
        for index, name in enumerate(["Prelims", "Mains", "Interview", "Final Result"], start=1):
            db.session.add(Stage(exam_id=exam.id, name=name, sort_order=index, enabled=(name in ("Prelims", "Mains"))))
        db.session.commit()
        reconcile_reminders(exam)
        db.session.commit()
        flash("Exam added.", "success")
        return redirect(url_for("main.exam_detail", exam_id=exam.id))
    return render_template("exam_form.html", exam=None)

@bp.route("/exams/<int:exam_id>")
def exam_detail(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    stats = HistoricalStat.query.filter_by(exam_name=exam.name).order_by(HistoricalStat.recruitment_year.desc()).all()
    return render_template("exam_detail.html", exam=exam, stats=stats)

@bp.route("/exams/<int:exam_id>/edit", methods=["GET", "POST"])
def exam_edit(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    if request.method == "POST":
        exam.name = request.form.get("name", "").strip() or exam.name
        for field in ("organization", "category", "post_name", "recruitment_year", "notification_url", "application_url", "interest_status", "registration_status", "application_number", "payment_status", "notes"):
            setattr(exam, field, request.form.get(field, "").strip())
        exam.registration_start = parse_date(request.form.get("registration_start"))
        exam.registration_end = parse_date(request.form.get("registration_end"))
        exam.application_date = parse_date(request.form.get("application_date"))
        exam.fee_amount = parse_float(request.form.get("fee_amount"))
        db.session.commit()
        reconcile_reminders(exam)
        db.session.commit()
        flash("Exam updated.", "success")
        return redirect(url_for("main.exam_detail", exam_id=exam.id))
    return render_template("exam_form.html", exam=exam)

@bp.post("/exams/<int:exam_id>/archive")
def exam_archive(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    exam.archived = not exam.archived
    db.session.commit()
    reconcile_reminders(exam)
    db.session.commit()
    flash("Exam archive status updated.", "success")
    return redirect(request.referrer or url_for("main.exams_list"))

@bp.post("/exams/<int:exam_id>/delete")
def exam_delete(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    db.session.delete(exam)
    db.session.commit()
    flash("Exam and its linked stages/reminders/documents were deleted.", "success")
    return redirect(url_for("main.exams_list"))

@bp.post("/exams/<int:exam_id>/stages")
def stage_update(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    stage_id = request.form.get("stage_id")
    stage = Stage.query.filter_by(id=stage_id, exam_id=exam.id).first() if stage_id else None
    if not stage:
        stage = Stage(exam_id=exam.id, name=request.form.get("name", "").strip() or "Custom Stage",
                      sort_order=len(exam.stages)+1)
        db.session.add(stage)
    stage.name = request.form.get("name", stage.name).strip() or stage.name
    stage.exam_date = parse_date(request.form.get("exam_date"))
    stage.exam_time = request.form.get("exam_time", "").strip()
    stage.admit_card_date = parse_date(request.form.get("admit_card_date"))
    stage.admit_card_url = request.form.get("admit_card_url", "").strip()
    stage.roll_number = request.form.get("roll_number", "").strip()
    stage.qualification_status = request.form.get("qualification_status", "Not Attempted")
    stage.result_date = parse_date(request.form.get("result_date"))
    stage.result_url = request.form.get("result_url", "").strip()
    stage.score = parse_float(request.form.get("score"))
    stage.qualifying_marks = parse_float(request.form.get("qualifying_marks"))
    stage.cutoff_marks = parse_float(request.form.get("cutoff_marks"))
    stage.total_marks = parse_float(request.form.get("total_marks"))
    stage.enabled = bool(request.form.get("enabled"))
    stage.notes = request.form.get("notes", "").strip()
    db.session.commit()
    reconcile_reminders(exam)
    db.session.commit()
    flash("Exam stage saved.", "success")
    return redirect(url_for("main.exam_detail", exam_id=exam.id) + "#stages")

@bp.post("/stages/<int:stage_id>/delete")
def stage_delete(stage_id):
    stage = Stage.query.get_or_404(stage_id)
    exam_id = stage.exam_id
    db.session.delete(stage)
    db.session.commit()
    exam = Exam.query.get(exam_id)
    if exam:
        reconcile_reminders(exam)
        db.session.commit()
    flash("Stage deleted.", "success")
    return redirect(url_for("main.exam_detail", exam_id=exam_id) + "#stages")

@bp.post("/stages/<int:stage_id>/marks")
def marks_add(stage_id):
    stage = Stage.query.get_or_404(stage_id)
    name = request.form.get("subject_name", "").strip()
    if not name:
        flash("Subject name is required.", "error")
        return redirect(url_for("main.exam_detail", exam_id=stage.exam_id) + "#marks")
    mark = SubjectMark(
        stage_id=stage.id, subject_name=name,
        maximum_marks=parse_float(request.form.get("maximum_marks")),
        marks_obtained=parse_float(request.form.get("marks_obtained")),
        qualifying_marks=parse_float(request.form.get("qualifying_marks")),
        cutoff_marks=parse_float(request.form.get("cutoff_marks")),
        contributes_to_merit=bool(request.form.get("contributes_to_merit")),
        is_qualifying_only=bool(request.form.get("is_qualifying_only")),
        notes=request.form.get("notes", "").strip()
    )
    db.session.add(mark)
    db.session.commit()
    flash("Subject marks saved.", "success")
    return redirect(url_for("main.exam_detail", exam_id=stage.exam_id) + "#marks")

@bp.post("/marks/<int:mark_id>/delete")
def marks_delete(mark_id):
    mark = SubjectMark.query.get_or_404(mark_id)
    exam_id = mark.stage.exam_id
    db.session.delete(mark)
    db.session.commit()
    return redirect(url_for("main.exam_detail", exam_id=exam_id) + "#marks")

@bp.route("/statistics", methods=["GET", "POST"])
def statistics():
    if request.method == "POST":
        exam_name = request.form.get("exam_name", "").strip()
        year = request.form.get("recruitment_year", "").strip()
        if not exam_name or not year:
            flash("Exam name and year are required.", "error")
            return redirect(url_for("main.statistics"))
        stat = HistoricalStat(
            exam_name=exam_name, organization=request.form.get("organization", "").strip(),
            recruitment_year=year, stage_name=request.form.get("stage_name", "").strip(),
            category=request.form.get("category", "All").strip(),
            vacancies=int(request.form["vacancies"]) if request.form.get("vacancies", "").isdigit() else None,
            candidates_registered=int(request.form["candidates_registered"]) if request.form.get("candidates_registered", "").isdigit() else None,
            candidates_appeared=int(request.form["candidates_appeared"]) if request.form.get("candidates_appeared", "").isdigit() else None,
            prelims_qualified=int(request.form["prelims_qualified"]) if request.form.get("prelims_qualified", "").isdigit() else None,
            mains_qualified=int(request.form["mains_qualified"]) if request.form.get("mains_qualified", "").isdigit() else None,
            interview_shortlisted=int(request.form["interview_shortlisted"]) if request.form.get("interview_shortlisted", "").isdigit() else None,
            final_selected=int(request.form["final_selected"]) if request.form.get("final_selected", "").isdigit() else None,
            overall_cutoff=parse_float(request.form.get("overall_cutoff")),
            source_url=request.form.get("source_url", "").strip(),
            verified_on=parse_date(request.form.get("verified_on")),
            notes=request.form.get("notes", "").strip()
        )
        db.session.add(stat)
        db.session.commit()
        flash("Historical statistic saved.", "success")
        return redirect(url_for("main.statistics"))
    stats = HistoricalStat.query.order_by(HistoricalStat.exam_name, HistoricalStat.recruitment_year.desc()).all()
    return render_template("statistics.html", stats=stats)

@bp.post("/statistics/<int:stat_id>/delete")
def statistics_delete(stat_id):
    stat = HistoricalStat.query.get_or_404(stat_id)
    db.session.delete(stat)
    db.session.commit()
    return redirect(url_for("main.statistics"))

@bp.route("/reminders")
def reminders():
    rows = Reminder.query.order_by(Reminder.due_date.asc(), Reminder.created_at.desc()).all()
    return render_template("reminders.html", reminders=rows)

@bp.post("/reminders/refresh")
def reminders_refresh():
    for exam in Exam.query.all():
        reconcile_reminders(exam)
    db.session.commit()
    flash("Reminder schedules refreshed.", "success")
    return redirect(url_for("main.reminders"))

@bp.route("/documents/<int:exam_id>", methods=["POST"])
def upload_document(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    file = request.files.get("file")
    title = request.form.get("title", "").strip() or "Document"
    if not file or not file.filename:
        flash("Choose a file first.", "error")
        return redirect(url_for("main.exam_detail", exam_id=exam.id) + "#documents")
    original = secure_filename(file.filename)
    ext = original.rsplit(".", 1)[-1].lower() if "." in original else ""
    if ext not in ALLOWED_EXTENSIONS:
        flash("Allowed file types: PDF, PNG, JPG, JPEG, DOC, DOCX.", "error")
        return redirect(url_for("main.exam_detail", exam_id=exam.id) + "#documents")
    stored = f"{uuid.uuid4().hex}_{original}"
    file.save(os.path.join(current_app.config["UPLOAD_FOLDER"], stored))
    db.session.add(Document(exam_id=exam.id, title=title, stored_name=stored, original_name=original))
    db.session.commit()
    flash("Document uploaded to private local storage.", "success")
    return redirect(url_for("main.exam_detail", exam_id=exam.id) + "#documents")

@bp.route("/documents/file/<int:document_id>")
def document_download(document_id):
    # Local single-user starter app. Add authentication before any network/public deployment.
    doc = Document.query.get_or_404(document_id)
    return send_from_directory(current_app.config["UPLOAD_FOLDER"], doc.stored_name,
                               as_attachment=True, download_name=doc.original_name)

@bp.post("/documents/<int:document_id>/delete")
def document_delete(document_id):
    doc = Document.query.get_or_404(document_id)
    exam_id = doc.exam_id
    path = Path(current_app.config["UPLOAD_FOLDER"]) / doc.stored_name
    if path.exists():
        path.unlink()
    db.session.delete(doc)
    db.session.commit()
    return redirect(url_for("main.exam_detail", exam_id=exam_id) + "#documents")

@bp.route("/api/exams")
def api_exams():
    exams = Exam.query.filter_by(archived=False).all()
    return jsonify([{"id": e.id, "name": e.name, "registration_end": e.registration_end.isoformat() if e.registration_end else None,
                     "registration_status": e.registration_status,
                     "stages": [{"name": s.name, "date": s.exam_date.isoformat() if s.exam_date else None,
                                 "status": s.qualification_status} for s in e.stages]} for e in exams])
