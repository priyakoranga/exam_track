# ExamTrack — Personal Exam Manager

A local-first Flask + SQLite application for tracking recruitment exams, registration deadlines, exam stages, results, marks, reminders, documents, and historical statistics.

## Requirements
- Python 3.10+
- pip

## Run on Windows (PowerShell)
```powershell
cd examtrack
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python run.py
```
Open http://127.0.0.1:5000

If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in that terminal, or activate from Command Prompt using `.venv\Scripts\activate.bat`.

## Run on macOS/Linux
```bash
cd examtrack
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python run.py
```

The database is created at `instance/examtrack.db`. Uploaded documents are kept in `instance/uploads/`. Back up both locations and keep them private.

## Features
- Dashboard and exam list/search/filter.
- Create, edit, archive, restore, and permanently delete exams.
- Registration dates/status and application identifiers.
- Prelims, Mains, Interview, Final Result, and custom stages.
- Stage date, roll number, admit-card/result links, score, cutoff, and qualification status.
- Subject-wise marks with sectional qualifying marks/cutoffs.
- In-app reminder schedule for registration deadlines and enabled stages.
- Historical statistics entry for vacancies, participation, qualification counts, cutoffs, and source URLs.
- Private local document upload/download route.
- JSON API at `/api/exams`.

## Reminder behavior and limitations
The background scheduler checks daily at 08:00 Asia/Kolkata. It records due reminders as `Sent` in the in-app history; this starter does **not** send email, SMS, or browser push notifications. Keep `python run.py` running for scheduled jobs. If the process is stopped, the scheduler does not run; due reminders will be processed after it starts again.

Stage reminders are planned 7, 3, and 1 days before an enabled stage date. Mains reminders are held until Prelims is marked `Qualified`; Interview reminders are held until Mains is marked `Qualified`. Registration reminders are planned 7, 3, 1, and 0 days before the closing date when the exam is marked `Interested` and is not `Registered`, `Not Interested`, or `Missed`.

## Security
This is a local single-user starter, not a production-ready hosted service. It does not yet implement login, CSRF protection, or user authorization. Do not expose it to the internet or upload sensitive documents unless you add authentication, authorization, CSRF protection, secure secret configuration, and appropriate storage controls. Do not put `instance/`, uploaded files, or your database into a public repository.

Set a stronger secret key before deployment:
- PowerShell: `$env:EXAMTRACK_SECRET_KEY = "replace-with-a-long-random-secret"`
- macOS/Linux: `export EXAMTRACK_SECRET_KEY="replace-with-a-long-random-secret"`

## Architecture
- `app/models.py`: database models.
- `app/routes.py`: web routes and request validation.
- `app/services.py`: reminder planning and business logic.
- `app/reminders.py`: background scheduler and in-app delivery.
- `app/templates/`: HTML pages.
- `app/static/`: CSS and browser-side JavaScript.
- `instance/`: runtime database and uploads (created automatically).

## Future improvements
Recommended next steps: automated tests, CSRF protection, login, email/push notification adapters, calendar export, CSV import/export, visual historical charts, database migrations, and production deployment setup.
